import React from 'react'
import Carousel from './Carousel'

import Navbar from './Navbar'
import Rules from './Rules'

const Home = () => {
  return (
    <div>
      <Navbar/>
     <Carousel/>
   <Rules/>
    </div>
  )
}

export default Home

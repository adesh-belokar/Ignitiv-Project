import React from 'react'
import "../CSS/emplogin.css"
import Navbar from './Navbar'
import { Link } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
const Emplogin= () => {
   
    
    return (
        <div>
            <Navbar />
            <div className='heading'><h2>EMPLOYE LOGIN FORM</h2></div>
            <div>
                <form className='login' method="post">
                    <div class="container container border border-dark border border-4 ">
                        <div className='row'>
                            <div class="mt-4 col ">
                                <label for="Name" class="form-label fw-bold"> Name:</label>
                                <input type="text" class="form-control" id="name" placeholder="Enter name"   required/>
                            </div>
                            <div class="mt-4 col">
                                <label for="Empid" class="form-label fw-bold">Employe Id:</label>
                                <input type="text" class="form-control" id="empid" placeholder="Enter Empolye Id" name="Empid"  required/>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success form-control green" >Submit</button>
                    </div>



                </form>
            </div>
        </div>
    )
}


export default Emplogin

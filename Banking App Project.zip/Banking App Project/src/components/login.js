import React from 'react'
import "../CSS/login.css"
import Navbar from './Navbar'
import { Link ,useNavigate} from 'react-router-dom'
const Login = () => {
    const [acc, setAcc] = React.useState("");
    const [Name, setName] = React.useState("");
    const [err, setErr] = React.useState("");
    const navigate = useNavigate();
const handlename=(event)=>
{console.log(event.target.value)
    setName(event.target.value)
   
}
const handleaccount=(event)=>
{
    setAcc(event.target.value)
    
}
    function handleLogin(e) {
        e.preventDefault();
        const getCustomerData = async () => {
            try {
                const result = await fetch(`http://localhost:4501/login/${Name}/${acc}`);
                const resp = await result.json();
                const data = JSON.stringify(resp[0])
                console.log(data)
                if (resp.length) {
                    sessionStorage.setItem("Account_Number", acc);
                    navigate("/Customer");
                }
                else {
                    setErr("Invalid Account Name and Password !")
                }

            }
            catch (error) {
                console.log(error);
            }
        }
        getCustomerData();
    }
        return (
            <div>
                <Navbar />
                <div className='heading'><h2> CUSTOMER LOGIN </h2></div>
                <div>
                    <form className='login'onSubmit={handleLogin} method="post">
                        <div class="container border border-dark border border-4 ">
                            <div className='row'>
                                <div class="mt-4 col ">
                                    <label for="Name" class="form-label fw-bold">Name:</label>
                                    <input type="text" class="form-control" id="name" placeholder="Enter name" required onChange={handlename}/>
                                </div>
                                <div class="mt-4 col">
                                    <label for="Accno" class="form-label fw-bold">Account Number:</label>
                                    <input type="text" class="form-control" id="accno" placeholder="Enter Account Number" required onChange={handleaccount} />
                                </div>
                                <span>{err}</span>
                            </div>

                            <button type="submit" class="btn btn-success form-control green" >Login</button>
                            <span ><Link to="/Registration">New Registration</Link></span>
                        </div>



                    </form>
                </div>
            </div>
        )
    }

    export default Login

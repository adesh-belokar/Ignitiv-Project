import logo from './logo.svg';
import './App.css';
import Login from './components/login';
import Home from './components/Home';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Resitration_form from './components/Resitration_form';
import Costomerpage from './components/Costomerpage';
import Withdraw from './components/Withdraw';
import Deposite from './components/Deposite';
import Checkbalance from './components/Checkbalance';
import Transfer from './components/Transfer';
import Footer from './components/Footer';
import Emplogin from './components/Emplogin';
import Employepage from './components/Employepage';

function App() {
  return (
   <div>
    <BrowserRouter>
    <Routes>
    <Route path='/' element={<Home/>}></Route>
    <Route path='/login' element={<Login/>}></Route>
    <Route path='/emplogin' element={<Emplogin/>}></Route>
    <Route path='/Registration' element={<Resitration_form />}></Route>
    <Route path='/Customer' element={<Costomerpage />}></Route>
    <Route path='/withdraw' element={< Withdraw/>}></Route>
    <Route path='/deposit' element={<Deposite/>}></Route>
    <Route path='/checkbal' element={< Checkbalance/>}></Route>
    <Route path='/transfer' element={<Transfer/>}></Route>
    <Route path='/emppage' element={<Employepage/>}></Route>
   
    </Routes>
    <Footer/>
    </BrowserRouter>
    
   
   </div> 
  );
}

export default App;
